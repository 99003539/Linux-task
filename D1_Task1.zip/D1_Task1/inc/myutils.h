#ifndef __MYUTILS_H__
#define __MYUTILS_H__
long factorial(int);
int check_prime(int);
int checkPalindrome(int number);
int vsum(int a, ...);
#endif