#ifndef __MYSTRING_H__
#define __MYSTRING_H__
int mystrlen(char* str1);
char* mystrcpy(char* str1, const char* str2);
char* mystrcat(char *str3, const char *str4);
int mystrcmp(const char* str5, const char* str6);
#endif