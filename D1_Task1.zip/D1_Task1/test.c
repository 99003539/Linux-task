#include "mystring.h"
#include "myutils.h"
#include<stdio.h>
#include<string.h>
int main()
{   
    int number;
    long fact = 1;
    int result;
    char city[20] = "HYDERABAD";
    char town[20] = "MANGALORE";
    char abc[20];
    printf("%d\n",mystrlen(city));
    printf("%s\n",mystrcpy(abc,city));
    printf("%s\n",mystrcat(city,town));
    printf("%d",mystrcmp(city,town));
    printf("%ld\n",factorial(3));
    if(checkPalindrome(number) == 0){
        printf("%d is a palindrome number.\n",number);}
    else if(checkPalindrome(number) == 1){
        printf("%d is not a palindrome number.\n",number);
    }
    result = check_prime(86);
    if ( result == 1 ){
      printf("It is prime number.\n");
    }
   else if(result == 0){
      printf("It is not prime number.\n");
   }
    printf("%d\n", vsum(3, 2, 3, 4));
    return 0;
}